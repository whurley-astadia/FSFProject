package com.astadia.fsf;

import java.io.Serializable;
import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class Rules implements Serializable {

	@SerializedName("rule")
	@Expose
	private List<Rule> rule = null;
	private final static long serialVersionUID = -9079198772907588619L;

	/**
	 * No args constructor for use in serialization
	 * 
	 */
	public Rules() {
	}

	/**
	 * 
	 * @param rule
	 */
	public Rules(List<Rule> rule) {
		super();
		this.rule = rule;
	}

	public List<Rule> getRule() {
		return rule;
	}

	public void setRule(List<Rule> rule) {
		this.rule = rule;
	}

	public Rules withRule(List<Rule> rule) {
		this.rule = rule;
		return this;
	}

	@Override
	public String toString() {
		return new ToStringBuilder(this).append("rule", rule).toString();
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(rule).toHashCode();
	}

	@Override
	public boolean equals(Object other) {
		if (other == this) {
			return true;
		}
		if ((other instanceof Rules) == false) {
			return false;
		}
		Rules rhs = ((Rules) other);
		return new EqualsBuilder().append(rule, rhs.rule).isEquals();
	}

}
