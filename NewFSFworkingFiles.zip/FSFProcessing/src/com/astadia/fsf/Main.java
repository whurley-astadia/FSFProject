package com.astadia.fsf;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import com.google.gson.Gson;

public class Main {

	public static void main(String args[]) {

		Gson gson = new Gson();
		BufferedReader br = null;

		try {
			// choice of file is based on name
			// this needs to changed to
			br = new BufferedReader(
					new FileReader(
							"C:\\Dev\\Testing\\Examples\\workspace\\FSFProcessing\\src\\TestRules3.JSON"));
			Rules rl = gson.fromJson(br, Rules.class);

			if (rl != null) {
				for (Rule r : rl.getRule()) {

					// System.out.println("The Object: " + r.toString());
					
					System.out.println("Rule Name:    " + r.getName());
					
					System.out.println("Decline Rule: " + r.getDeclineRule());
					
					System.out.println("SQL getSQLColumns:         "
					
										+ r.getSQLColumns());
					
					System.out.println("SQL get Left Sqlwhere:     "
										+ r.getLeftSQLWhere());
					
					System.out.println("SQL get Negitive Sqlwhere: "
										+ r.getNegSQLWhere());
					

				}

			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}

	}
}
