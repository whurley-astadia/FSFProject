package com.astadia.fsf;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class Rule implements Serializable {

	@SerializedName("name")
	@Expose
	private String name;
	@SerializedName("declineRule")
	@Expose
	private String declineRule;
	@SerializedName("sqlwhere")
	@Expose
	private List<String> sqlwhere = null;
	private final static long serialVersionUID = -1428694939223633003L;

	// additions to build columns and SQL statements
	private  String columnnames;
	private  String leftSQLWhere;
	private  String negSQLWhere;

	// required to process operators for negative SQL
	private String eq =   " = ";
	private String neq =  " <> ";
	private String gt =   " > ";
	private String lt =   " < ";
	private String gteq = " >= ";
	private String lteq = " <= ";

	/**
	 * No args constructor for use in serialization
	 * 
	 */
	public Rule() {
	}

	/**
	 * 
	 * @param sqlwhere
	 * @param declineRule
	 * @param name
	 */
	public Rule(String name, String declineRule, List<String> sqlwhere) {
		super();
		this.name = name;
		this.declineRule = declineRule;
		this.sqlwhere = sqlwhere;

	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Rule withName(String name) {
		this.name = name;
		return this;
	}

	public String getDeclineRule() {
		return declineRule;
	}

	public void setDeclineRule(String declineRule) {
		this.declineRule = declineRule;
	}

	public Rule withDeclineRule(String declineRule) {
		this.declineRule = declineRule;
		return this;
	}

	public List<String> getSqlwhere() {
		return sqlwhere;
	}

	
	public String getSQLColumns() {
		sqlColumns();
		return columnnames.concat(", POLICY_RULES_USED, UNDRWRTE_STRAT_IN");
	}

	public String getLeftSQLWhere() {
		leftSQLWhere();
		return leftSQLWhere;
	}

	public String getNegSQLWhere() {
		negSQLWhere();
		return negSQLWhere;
	}

	private void sqlColumns() {

		String clean, sColumns;
		ArrayList<String> uniqueColumns = new ArrayList<String>();

		for (String temp : this.sqlwhere) {

			clean = temp.split(" ", 2)[0];
			clean = clean.replace('(', ' ');
			clean = clean.replace(')', ' ');
			clean = clean.trim();
			
			// If this element is not present in newList then add it 
			
			if (!uniqueColumns.contains(clean)) uniqueColumns.add(clean); 
		
		}

		 sColumns = uniqueColumns.toString().replace('[', ' ');
		 
		 this.columnnames = sColumns.replace(']', ' ').trim();

	}

	private void negSQLWhere() {

		String   clean;
			
		StringBuilder sb = new StringBuilder();

		for (String temp : this.sqlwhere) {
			
			String 	sclean = new String ();

			clean = temp.toUpperCase();

			if (temp.contains(eq)) 	sclean = clean.replaceAll(eq, neq);

			if (temp.contains(neq)) 	sclean = clean.replaceAll(neq, eq);

			if (temp.contains(gt)) 	sclean = clean.replaceAll(gt, lteq);

			if (temp.contains(lt)) 	sclean = clean.replaceAll(lt, gteq);

			if (temp.contains(gteq)) 	sclean = clean.replaceAll(gteq, lt);

			if (temp.contains(lteq)) 	sclean = clean.replaceAll(lteq, gt);
			
			if(sclean.isEmpty()) sb.append(clean);

			sb.append(sclean).append(" ");

		}

		this.negSQLWhere = sb.toString();
	}

	private void leftSQLWhere() {

		String clean;
		StringBuilder sb = new StringBuilder();

		for (String temp : this.sqlwhere) {

			clean = temp.toUpperCase();
			sb.append(clean).append(" ");

		}

		this.leftSQLWhere = sb.toString();
	}

	public void setSqlwhere(List<String> sqlwhere) {
		this.sqlwhere = sqlwhere;
	}

	public Rule withSqlwhere(List<String> sqlwhere) {
		this.sqlwhere = sqlwhere;

		return this;
	}

	@Override
	public String toString() {
		return new ToStringBuilder(this).append("name", name)
				.append("declineRule", declineRule)
				.append("sqlwhere", sqlwhere).toString();
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(sqlwhere).append(declineRule)
				.append(name).toHashCode();
	}

	@Override
	public boolean equals(Object other) {
		if (other == this) {
			return true;
		}
		if ((other instanceof Rule) == false) {
			return false;
		}
		Rule rhs = ((Rule) other);
		return new EqualsBuilder().append(sqlwhere, rhs.sqlwhere)
				.append(declineRule, rhs.declineRule).append(name, rhs.name)
				.isEquals();
	}

}
