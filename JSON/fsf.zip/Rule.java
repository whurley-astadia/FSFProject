package com.astadia.fsf;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class Rule implements Serializable {

	@SerializedName("name")
	@Expose
	private String name;
	@SerializedName("declineRule")
	@Expose
	private String declineRule;
	@SerializedName("sqlwhere")
	@Expose
	private List<String> sqlwhere = null;
	private final static long serialVersionUID = -1428694939223633003L;

	// additions to build columns and SQL statements
	private  String columnnames;
	private  String leftSQLWhere;
	private  String negSQLWhere;

	// required to process operators for negative SQL
	private String eq = "=";
	private String neq = "<>";
	private String gt = "> ";
	private String lt = "< ";
	private String gteq = ">=";
	private String lteq = "<=";

	/**
	 * No args constructor for use in serialization
	 * 
	 */
	public Rule() {
	}

	/**
	 * 
	 * @param sqlwhere
	 * @param declineRule
	 * @param name
	 */
	public Rule(String name, String declineRule, List<String> sqlwhere) {
		super();
		this.name = name;
		this.declineRule = declineRule;
		this.sqlwhere = sqlwhere;

	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Rule withName(String name) {
		this.name = name;
		return this;
	}

	public String getDeclineRule() {
		return declineRule;
	}

	public void setDeclineRule(String declineRule) {
		this.declineRule = declineRule;
	}

	public Rule withDeclineRule(String declineRule) {
		this.declineRule = declineRule;
		return this;
	}

	public List<String> getSqlwhere() {
		return sqlwhere;
	}

	// TODO need to remove non Chars off the front of column names.
	// TODO NEED TO TRIM LAST COMMA

	public String getSQLColumns() {
		sqlColumns();
		return columnnames;
	}

	public String getLeftSQLWhere() {
		leftSQLWhere();
		return leftSQLWhere;
	}

	public String getNegSQLWhere() {
		negSQLWhere();
		return negSQLWhere;
	}

	private void sqlColumns() {

		String clean;
		StringBuffer sb = new StringBuffer();

		for (String temp : this.sqlwhere) {

			clean = temp.split(" ", 2)[0];
			sb.append(clean).append(", ");

		}

		this.columnnames = sb.toString();

	}

	private void negSQLWhere() {

		String clean, _clean = "";
		StringBuffer sb = new StringBuffer();

		for (String temp : this.sqlwhere) {

			clean = temp.toUpperCase();

			if (clean.contains(eq))
				_clean = clean.replaceAll(eq, neq);

			if (clean.contains(neq))
				_clean = clean.replaceAll(neq, eq);

			if (clean.contains(gt))
				_clean = clean.replaceAll(gt, lt);

			if (clean.contains(lt))
				_clean = clean.replaceAll(lt, gt);

			if (clean.contains(gt))
				_clean = clean.replaceAll(gt, lt);

			if (clean.contains(gteq))
				_clean = clean.replaceAll(gteq, lt);

			if (clean.contains(lteq))
				_clean = clean.replaceAll(lteq, gt);

			sb.append(_clean);

		}

		this.negSQLWhere = sb.toString();
	}

	private void leftSQLWhere() {

		String clean;
		StringBuffer sb = new StringBuffer();

		for (String temp : this.sqlwhere) {

			clean = temp.toUpperCase();
			sb.append(clean).append(" ");

		}

		this.leftSQLWhere = sb.toString();
	}

	public void setSqlwhere(List<String> sqlwhere) {
		this.sqlwhere = sqlwhere;
	}

	public Rule withSqlwhere(List<String> sqlwhere) {
		this.sqlwhere = sqlwhere;

		return this;
	}

	@Override
	public String toString() {
		return new ToStringBuilder(this).append("name", name)
				.append("declineRule", declineRule)
				.append("sqlwhere", sqlwhere).toString();
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(sqlwhere).append(declineRule)
				.append(name).toHashCode();
	}

	@Override
	public boolean equals(Object other) {
		if (other == this) {
			return true;
		}
		if ((other instanceof Rule) == false) {
			return false;
		}
		Rule rhs = ((Rule) other);
		return new EqualsBuilder().append(sqlwhere, rhs.sqlwhere)
				.append(declineRule, rhs.declineRule).append(name, rhs.name)
				.isEquals();
	}

}
